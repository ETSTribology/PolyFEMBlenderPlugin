from numpy._core.defchararray import __all__, __doc__
from numpy._core.defchararray import *
