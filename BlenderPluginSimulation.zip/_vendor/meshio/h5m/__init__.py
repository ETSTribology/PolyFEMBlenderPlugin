from ._h5m import read, write

__all__ = ["read", "write"]
