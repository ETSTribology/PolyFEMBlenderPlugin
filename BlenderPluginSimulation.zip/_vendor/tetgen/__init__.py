"""Tetgen module."""
from ..tetgen import _tetgen
from ..tetgen._version import __version__
from ..tetgen.pytetgen import TetGen
