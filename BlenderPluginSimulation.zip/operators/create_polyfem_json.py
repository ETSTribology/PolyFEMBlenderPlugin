import bpy
import json
import os
import subprocess
from bpy.props import StringProperty
from bpy.types import Operator

# Operator to create the JSON file
class CreatePolyFemJSONOperator(Operator):
    """Create a JSON configuration file for PolyFem simulation"""
    bl_idname = "polyfem.create_json"
    bl_label = "Create PolyFEM JSON"
    bl_description = "Generate a JSON configuration file for PolyFEM simulation and export selected meshes"
    bl_options = {'REGISTER', 'UNDO'}

    json_filename: StringProperty(
        name="JSON Filename",
        description="Name of the JSON configuration file",
        default="polyfem_config.json",
    )

    def execute(self, context):
        settings = context.scene.polyfem_json_settings
        project_path = bpy.path.abspath(settings.project_path)
        json_filename = self.json_filename
        json_path = os.path.join(project_path, json_filename)

        # Define the JSON data structure
        json_data = {
            "contact": {
                "enabled": settings.contact_enabled,
                "dhat": settings.contact_dhat,
                "friction_coefficient": settings.contact_friction_coefficient,
                "epsv": settings.contact_epsv
            },
            "time": {
                "integrator": settings.time_integrator,
                "tend": settings.time_tend,
                "dt": settings.time_dt
            },
            "space": {
                "advanced": {
                    "bc_method": settings.space_bc_method
                }
            },
            "boundary_conditions": {
                "rhs": [settings.boundary_rhs_x, settings.boundary_rhs_y, settings.boundary_rhs_z]
            },
            "materials": {
                "type": settings.materials_type,
                "E": settings.materials_E,
                "nu": settings.materials_nu,
                "rho": settings.materials_rho
            },
            "solver": {
                "linear": {
                    "solver": settings.solver_linear_solver
                },
                "nonlinear": {
                    "x_delta": settings.solver_nonlinear_x_delta
                },
                "advanced": {
                    "lump_mass_matrix": settings.solver_advanced_lump_mass_matrix
                },
                "contact": {
                    "friction_convergence_tol": settings.solver_contact_friction_convergence_tol,
                    "friction_iterations": settings.solver_contact_friction_iterations
                }
            },
            "output": {
                "json": settings.output_json,
                "paraview": {
                    "file_name": settings.output_paraview_file_name,
                    "options": {
                        "material": settings.output_paraview_material,
                        "body_ids": settings.output_paraview_body_ids,
                        "tensor_values": settings.output_paraview_tensor_values,
                        "nodes": settings.output_paraview_nodes
                    },
                    "vismesh_rel_area": settings.output_paraview_vismesh_rel_area
                },
                "advanced": {
                    "save_solve_sequence_debug": settings.output_advanced_save_solve_sequence_debug,
                    "save_time_sequence": settings.output_advanced_save_time_sequence
                }
            }
        }

        # Try to write the JSON configuration file
        try:
            with open(json_path, 'w') as json_file:
                json.dump(json_data, json_file, indent=4)
            self.report({'INFO'}, f"JSON file created at '{json_path}'")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to create JSON file: {e}")
            return {'CANCELLED'}

        # Now, let's export the selected objects as STL or OBJ files
        output_dir = os.path.join(project_path, "exported_meshes")
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

        objects_to_export = context.selected_objects
        if not objects_to_export:
            self.report({'WARNING'}, "No objects selected for export.")
            return {'CANCELLED'}

        for obj in objects_to_export:
            if obj.type != 'MESH':
                continue  # Skip non-mesh objects

            mesh_filename = f"{obj.name}.stl"  # Using STL format as an example
            mesh_filepath = os.path.join(output_dir, mesh_filename)
            
            if not self.export_mesh_to_stl(obj, mesh_filepath):
                self.report({'ERROR'}, f"Failed to export {obj.name} mesh.")
                return {'CANCELLED'}

            # Run TetWild on the exported STL mesh to generate MSH file
            msh_filepath = os.path.join(output_dir, f"{obj.name}.msh")
            if not self.run_tetwild(mesh_filepath, msh_filepath):
                self.report({'ERROR'}, f"Failed to process {obj.name} with TetWild.")
                return {'CANCELLED'}

        self.report({'INFO'}, f"Meshes exported and processed successfully in '{output_dir}'")
        return {'FINISHED'}

    def export_mesh_to_stl(self, obj, filepath):
        """Exports the mesh data of an object to an STL file."""
        mesh = obj.to_mesh()
        mesh.calc_loop_triangles()

        with open(filepath, 'w') as stl_file:
            stl_file.write(f'solid {obj.name}\n')

            for tri in mesh.loop_triangles:
                normal = tri.normal
                stl_file.write(f'facet normal {normal.x} {normal.y} {normal.z}\n')
                stl_file.write('  outer loop\n')
                for vertex_index in tri.vertices:
                    vertex = mesh.vertices[vertex_index].co
                    stl_file.write(f'    vertex {vertex.x} {vertex.y} {vertex.z}\n')
                stl_file.write('  endloop\n')
                stl_file.write('endfacet\n')

            stl_file.write(f'endsolid {obj.name}\n')

        obj.to_mesh_clear()
        return True

    def run_tetwild(self, input_file, output_file, ideal_edge_length=0.05, epsilon=1e-3, filter_energy=10, max_pass=80):
        """Run TetWild via Docker to generate an MSH file from a mesh."""
        # Build the command string with the required parameters
        command = [
            "docker", "run", "--rm",
            "-v", f"{os.path.abspath(os.path.dirname(input_file))}:/data",  # Mount the directory containing the input file
            "yixinhu/tetwild",  # Docker image
            "--input", f"{os.path.basename(input_file)}",  # Input file path in container
            "--ideal-edge-length", str(ideal_edge_length),
            "--epsilon", str(epsilon),
            "--filter-energy", str(filter_energy),
            "--max-pass", str(max_pass),
            "--output", f"{os.path.basename(output_file)}"  # Output file
        ]

        # Execute the command
        try:
            result = subprocess.run(command, check=True, capture_output=True, text=True)
            print(f"TetWild ran successfully with input: {input_file}")
            print(result.stdout)
            return True
        except FileNotFoundError:
            self.report({'ERROR'}, "Docker not found. Please ensure Docker is installed and in your system's PATH.")
            return False
        except subprocess.CalledProcessError as e:
            self.report({'ERROR'}, f"Error running TetWild: {e}")
            return False

    def invoke(self, context, event):
        """Invoke the operator and bring up the file browser."""
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        """Draw the operator's properties in the UI."""
        layout = self.layout
        layout.prop(self, "json_filename")